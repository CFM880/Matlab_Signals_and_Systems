a=[1,3,2];
b=[3];
impulse(b,a)