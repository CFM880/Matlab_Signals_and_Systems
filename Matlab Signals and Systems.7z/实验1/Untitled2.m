a=[1,3,2];
b=[3];
step(b,a)