close all;
clear;
clc;
a=[1];
b=[0.5,1];
impz(b,a,0:10)