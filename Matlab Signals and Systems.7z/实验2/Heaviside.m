function f=Heaviside(t)
f=(t>0);