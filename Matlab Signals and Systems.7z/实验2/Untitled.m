syms w;
ezplot(dirac(w))