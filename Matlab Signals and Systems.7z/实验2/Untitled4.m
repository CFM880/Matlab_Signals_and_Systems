clear;
close all;
clc;
a=[1,0.4,1];
b=[1,0,0];
freqs(b,a)
grid off;