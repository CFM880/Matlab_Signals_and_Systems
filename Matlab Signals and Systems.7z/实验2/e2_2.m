clear;
close all;
clc
syms x
f=dirac(x);
F=fourier(f)