clf
x=3
plot([-x,x],[0,3]);