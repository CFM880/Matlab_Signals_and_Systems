clf
a=[2,-5,2];
b=[-3,0]
nljdt(a,b)