clear;
close all;
clc
a=[8,2,3,1,5];
b=[1,3,2];
ljdt(a,b);