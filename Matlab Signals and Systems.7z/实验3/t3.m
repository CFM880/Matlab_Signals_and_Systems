clear;
close all;
clc
d=[1 4 3];
p=roots(d)