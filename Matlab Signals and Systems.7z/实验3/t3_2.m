clear;
close all;
clc
a=[1,5,16,30];
b=[5,20,25,0];
ljdt(a,b);