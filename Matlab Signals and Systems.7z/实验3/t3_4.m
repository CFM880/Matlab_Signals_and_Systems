clear;
close all;
clc
d=[1,0.75,0.125];
p=roots(d)