clear;
clc
a=[1,3/4,1/8];
b=[1,-0.5,0];
clf
nljdt(a,b)