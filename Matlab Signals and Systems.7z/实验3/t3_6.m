clf
a=[3,-1,0,0,0,1]
b=[1,1];
nljdt(a,b);